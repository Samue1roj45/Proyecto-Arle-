import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../context/UserContext";

export default function Registro() {
  const { setUser } = useUser();
  const [nombre, setNombre] = useState("");
  const [foto, setFoto] = useState(null);
  const navigate = useNavigate();

  const handleFoto = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setFoto(ev.target.result);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!nombre) return;
    setUser({ nombre, foto });
    navigate("/");
  };

  return (
    <div className="p-6">
      <h2 className="text-xl mb-4">Registro de Usuario</h2>
      <form onSubmit={handleSubmit} className="flex flex-col gap-3 max-w-sm">
        <input type="text" placeholder="Nombre" value={nombre} onChange={(e) => setNombre(e.target.value)} className="p-2 rounded text-black" required />
        <input type="file" accept="image/*" onChange={handleFoto} />
        <button type="submit" className="bg-green-600 p-2 rounded">Registrarse</button>
      </form>
      {foto && <img src={foto} alt="preview" className="mt-4 w-24 h-24 rounded-full object-cover" />}
    </div>
  );
}
