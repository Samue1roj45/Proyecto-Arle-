import { useUser } from "../context/UserContext";
import { useState } from "react";
import { Link } from "react-router-dom";

function Avatar() {
  const { user, setUser } = useUser();
  const [open, setOpen] = useState(false);

  const handleLogout = () => {
    setUser(null);
    setOpen(false);
  };

  return (
    <div className="relative">
      <div
        className="w-10 h-10 rounded-full bg-green-600 flex items-center justify-center cursor-pointer overflow-hidden"
        onClick={() => setOpen(!open)}
      >
        {user?.foto ? (
          <img src={user.foto} alt="avatar" className="w-full h-full object-cover" />
        ) : (
          <span className="text-lg font-bold">
            {user?.nombre?.charAt(0).toUpperCase()}
          </span>
        )}
      </div>
      {open && (
        <div className="absolute right-0 mt-2 bg-slate-800 rounded-lg shadow-lg p-2 w-40">
          <Link to="/perfil" className="block px-2 py-1 hover:bg-slate-700">Perfil</Link>
          <button onClick={handleLogout} className="block w-full text-left px-2 py-1 hover:bg-slate-700">Cerrar sesión</button>
        </div>
      )}
    </div>
  );
}

export default Avatar;
