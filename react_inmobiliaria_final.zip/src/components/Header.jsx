import { Link } from "react-router-dom";
import Avatar from "./Avatar";
import { useUser } from "../context/UserContext";

function Header() {
  const { user } = useUser();

  return (
    <header className="bg-slate-800 p-4 flex justify-between items-center">
      <h1 className="text-xl font-bold">🏡 Habi</h1>
      <nav className="flex gap-4">
        <Link to="/">Inicio</Link>
        <Link to="/comprar">Comprar</Link>
        <Link to="/arrendar">Arrendar</Link>
        <Link to="/vender">Vender</Link>
        <Link to="/hipoteca">Hipoteca</Link>
        <Link to="/contacto">Agentes</Link>
        <Link to="/favoritos">Favoritos</Link>
      </nav>
      <div>{user ? <Avatar /> : <Link to="/registro">Registrarse</Link>}</div>
    </header>
  );
}

export default Header;
