import { Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Home from "./pages/Home";
import Comprar from "./pages/Comprar";
import Arrendar from "./pages/Arrendar";
import Vender from "./pages/Vender";
import Hipoteca from "./pages/Hipoteca";
import Favoritos from "./pages/Favoritos";
import Contacto from "./pages/Contacto";
import Registro from "./pages/Registro";
import Perfil from "./pages/Perfil";

function App() {
  return (
    <div className="bg-slate-900 text-white min-h-screen">
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/comprar" element={<Comprar />} />
        <Route path="/arrendar" element={<Arrendar />} />
        <Route path="/vender" element={<Vender />} />
        <Route path="/hipoteca" element={<Hipoteca />} />
        <Route path="/favoritos" element={<Favoritos />} />
        <Route path="/contacto" element={<Contacto />} />
        <Route path="/registro" element={<Registro />} />
        <Route path="/perfil" element={<Perfil />} />
      </Routes>
    </div>
  );
}

export default App;
